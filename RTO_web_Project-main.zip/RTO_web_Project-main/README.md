# How to use

- type `npm i` to add all the dependencies of node/express js
- Goto config open `create_your_config.json`
- Enter your username and password for ex. you might be having default username `root` and password `12345`, sql password
- replace only in **first para**
- Make sure you have sql installed and running !!
- Also install sequeelize and all other dependencies (npm i)
- Then create a database of `fakedata1` (as mention in `config.json`) in your sql database.
- It should start working now.
- Try typing `nodemon index.js` (make sure you are in right directory)
